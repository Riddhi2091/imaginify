import React from 'react'

export default function AddTranformationTypePage() {
  return (
    <div>AddTranformationTypePage</div>
  )
}
