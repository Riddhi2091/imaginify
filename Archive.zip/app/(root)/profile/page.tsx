import React from 'react'

export default function ProfilePage() {
  return (
    <div>ProfilePage</div>
  )
}
