import React from 'react'

export default function CreditPage() {
  return (
    <div>CreditPage</div>
  )
}
